worker: node bot.js
